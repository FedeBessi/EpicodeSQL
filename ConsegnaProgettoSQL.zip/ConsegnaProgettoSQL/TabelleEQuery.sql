-- create database toysgroup
-- use toysgroup;

-- Product
create	table if not exists Product (
	IdProduct int auto_increment primary key,
    NameProd varchar(100),
    Category varchar(100),
    DescrPr varchar(1000),
    Weight decimal check(Weight>0),
    Model varchar(100),
    SellingUnitPrice decimal(5,2)
    );
    -- drop table product;
select *
from product;
-- TableGames
insert into product(NameProd,Category,DescrPr,Weight,Model,SellingUnitPrice)
values	('Risiko','TableGames','WarGame',5.0,'Classic',7.5),
        ('Risiko','TableGames','WarGame',5.0,'FutuRisiko',3.4),
        ('Monopoli','TableGames','Management',5.0,'Classic',2.99),
        ('Monopoli','TableGames','Management',5.0,'GameOfThrones',8.99),
        ('Cluedo','TableGames','Thriller',5.0,'Classic',9.99)        
        ;
        -- Cards
        insert into product(NameProd,Category,DescrPr,Weight,Model,SellingUnitPrice)
values	('Poker','Cards','-',0.5,'Classic',7.5),
        ('Pokemon','Cards','-',0.5,'Original',5.3),
        ('Magic','Cards','-',0.5,'Classic',9.99),
        ('Briscola','Cards','-',0.5,'Casinò',3.99)                
        ;
-- Region
create table if not exists Region(
IdRegion int primary key auto_increment,
NameRegion varchar(50) not null
);

insert into Region(NameRegion)
values	
('Europa'),
('Africa'),
('AmericaSett'),
('AmericaMerid'),
('Oceania'),
('Asia');

select *
from Region;

-- Sales
create table if not exists Sales (
	IdSale int primary key auto_increment,
    Quantity int,
    SaleDate date,
    State varchar(50),
    IdRegion int,
    IdProduct int,
    foreign key(IdRegion) references Region(IdRegion),
    foreign key(IdProduct) references Product(IdProduct)
    );
    
    drop table sales;
select *
from sales;
    
    insert into Sales(Quantity,SaleDate,State,IdRegion,IdProduct) values
				
		(5,'2005-07-06','Italy',1,3),
		(1,'2020-12-23','Italy',1,2),
        (2,'2021-10-23','France',1,5),
		(5,'2015-07-06','UK',1,3),
		(6,'2024-12-23','Italy',1,2),
        (2,'2023-10-23','USA',3,5),
        (5,'2005-07-06','Italy',1,3),
		(1,'2020-12-23','Italy',1,2),
        (2,'2010-10-23','France',1,5),			
		(5,'2015-07-06','UK',1,6),
		(6,'2024-12-23','Italy',1,8),
        (2,'2023-10-23','USA',3,9),
        (5,'2005-07-06','Italy',1,7),
		(1,'2020-12-23','Italy',1,6),
        (2,'2010-10-23','France',1,8);
    
select year(SaleDate)
from sales;

-- QUERY

-- 1) Verificare che i campi pk siano univoci

-- Product

select count(*)
from product;

select count(distinct(IdProduct))
from product;

-- Region

select count(*)
from region;

select count(distinct(IdRegion))
from region;     

-- Sales

select count(*)
from sales;

select count(distinct(IdSale))
from sales;

-- 2)Esporre l'elenco dei soli prodotti venduti e per ognuno di essi il fatturato totale di ogni anno


select s.idProduct,year(SaleDate),sum(p.SellingUnitPrice*s.Quantity)
from sales s join product p on s.IdProduct=p.IdProduct
group by idProduct,year(saledate);



-- 3) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

select State,year(SaleDate),sum(p.SellingUnitPrice*s.Quantity) as totFact
from sales s join product p on s.IdProduct=p.IdProduct
group by State,year(saledate)
order by year(s.SaleDate), totFact desc;

-- se con 'stato' si intende regione della tabella Region:

-- con la vista calcolo il fatturato totale per Regione per anno, ordinando per data e per fatturato decrescente
create view FatturatoRegione as
select IdRegion,year(SaleDate) as anno ,sum(p.SellingUnitPrice*s.Quantity) as totFact
from sales s join product p on s.IdProduct=p.IdProduct
group by IdRegion ,year(saledate)
order by year(s.SaleDate), totFact desc;

-- la Successiva query serve per introdurre il nome della regione al posto dell'idRegion.

select r.NameRegion,f.anno,totFact
from region r join FatturatoRegione f on r.IdRegion=f.IdRegion
order by anno, totfact;

-- L'ordinamento per fatturato è poco sensato perchè avendo raggruppato per anno e per fatturato,
-- ad ogni anno corrisponde un solo fatturato. Poiché il primo ordinamento è sull'anno e il secondo sul fatturato,
-- quest'ultimo non sortirà alcun effetto.

-- 4) Qual è la categoria di articoli maggiormente richiesta dal mercato?
						
		create view NCategory as
                        select Category, count(*) as TotCat
						from sales s join product p on s.IdProduct=p.IdProduct
						group by Category
                        ;
                     -- La vista conta quanti sono i prodotti venduti per ciascuna categoria
		
        select Category, totcat
        from ncategory
        where totcat= (     select max(totcat)
							from ncategory
                            );
                            
                            -- la subquery calcola la categoria più venduta dalla view
                            -- quella esterna serve per affiancare il nome della categoria al massimo selezionato nella subquery


-- 5)  quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

-- primo metodo: distinct

select p.IdProduct,NameProd,model
from product p
where p.IdProduct not in (
							select distinct(s.IdProduct)
                            from sales s
                            );
                            
-- secondo metodo: left join
select p.IdProduct,NameProd,model
from product p
where p.IdProduct not in (
							select s.IdProduct
                            from sales s left join product p on s.IdProduct=p.IdProduct
                            );
                            
-- terzo metodo: View+left join

create view LJSalesProd as 
select s.IdProduct
from sales s left join product p on s.IdProduct=p.IdProduct;

select p.IdProduct,NameProd,model
from product p
where p.IdProduct not in (
							select IdProduct
                            from LJSalesProd
                            );
                            
-- 6) Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)

-- la view calcola l'elenco dei prodotti con la rispettiva ultima data di vendita
create view PLastSale as
						select s.IdProduct,max(s.SaleDate) as LastSaledate
						from sales s
						group by IdProduct;
                        
select p.IdProduct,NameProd,Category,Model,LastSaledate
from product p join plastsale l on p.IdProduct=l.IdProduct;

-- l'ultima query serve per associare i dati del prodotto all'idProdoto estratto nella vista precedente
                        

